旧飞鹅垃圾填埋场开挖综合治理可行性研究报告

feie_feasibility_report.docx：可编辑 Word 报告
feie_feasibility_report.pdf：38 页 PDF 报告
feie_investment_model.xlsx：投资与收益测算表

本报告为可研决策稿。玉龙案例部分数据按用户附件线索编制，尚待官方资料核验；投资、收益及工期为报告所列假设下的测算结果。
